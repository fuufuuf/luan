var p={};
p.c1 = 1;
p.c2 = 2;
console.log(p);


