module.exports = {
cookieSecret: 'superman',
db: 'aluan',
port: '27017',
host: '101.200.174.136',
username: 'brotec',
password: '350602'
};